import React, { useState, useEffect } from 'react';
import { Fragment } from 'react';
import { BrowserRouter as Router, Route, useHistory } from 'react-router-dom';
import Header from '../../common/header/Header';
import { Button, Grid, TextField, Typography } from '@material-ui/core';
import './Home.css';
import { makeStyles } from '@material-ui/core/styles';
import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
import GridListTileBar from '@material-ui/core/GridListTileBar';
import { useSelector } from "react-redux";
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import { FormControl } from '@material-ui/core';
import { InputLabel } from '@material-ui/core';
import { Input, ListItemText } from '@material-ui/core';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import Checkbox from '@material-ui/core/Checkbox';
import Details from '../details/Details';
import { Link } from 'react-router-dom';
const useStyles = makeStyles((theme) => ({
    root: {
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-around',
        overflow: 'hidden',
        backgroundColor: theme.palette.background.paper,
    },
    rootComp: {
        
    },
    formControl: {
        minWidth: 240,
        maxWidth : 240,
        margin: theme.spacing.unit,
    },
    gridList: {
        flexWrap: 'nowrap',
        // Promote the list into his own layer on Chrome. This cost memory but helps keeping high FPS.
        transform: 'translateZ(0)',
    },
    title: {
        color: theme.palette.primary.light,
    },
    icon: {
        color: 'rgba(255, 255, 255, 0.54)',
    },
}));
const names = [
    'Oliver Hansen',
    'Van Henry',
    'April Tucker',
    'Ralph Hubbard',
    'Omar Alexander',
    'Carlos Abbott',
    'Miriam Wagner',
    'Bradley Wilkerson',
    'Virginia Andrews',
    'Kelly Snyder',
];


export default function Home(props) {
    const moviesList = useSelector(state => state.movieslist)
    const releaseList = useSelector(state => state.releaselist)
    const genrelist = useSelector(state => state.genreList);
    const artistlist = useSelector(state => state.artistList);
    const movieId = useSelector(state => state.movieID);
    const classes = useStyles();
    const history = useHistory();
    const movieClickHandler = (movieId) => {
        props.movieDetail(movieId);
        setTimeout(() => {
            history.push({pathname: "/movie/" +movieId});
        }, 1000);
    }

    function releaseDate(releasedate) {
        var dateobj = new Date(releasedate);
        return dateobj.toDateString();
    }
    const [genres, setGenres] = useState([]);
    const [artists, setArtists] = useState([]);
    return (

        <div>
            <Header />
            <div className="sub-heading">UpComing Movies</div>
            <div className={classes.root}>
                <GridList cols={6} className={classes.gridList}>
                    {moviesList.map((tile) => (
                        <GridListTile key={tile.poster_url} cellHeight={250} >

                            <img src={tile.poster_url} alt={tile.title} />
                            <GridListTileBar
                                title={tile.title}
                            />
                        </GridListTile>
                    ))}
                </GridList>
            </div>

            <div className="page-content">
                <div className="movies-listing">
                    <div className={classes.root}>
                        <GridList cols={4} cellHeight={350}>
                            {releaseList.map((tile) => (

                                <GridListTile key={tile.poster_url} className="released-movie-grid-item" >

                                    <img src={tile.poster_url} onClick={() => movieClickHandler(tile.id)} alt={tile.title} />
                                    <GridListTileBar
                                        title={tile.title}
                                        subtitle={<span>Release Date: {releaseDate(tile.release_date)}</span>}
                                    />
                                </GridListTile>
                            ))}
                        </GridList>
                    </div>


                </div>
                <div className="movies-filtering">
                    <Card >
                        <CardContent>
                            <FormControl >
                                <Typography className={classes.title} color="textSecondary">
                                    FIND MOVIES BY:
                            </Typography>
                            </FormControl>

                            <FormControl className={classes.formControl}>
                                <InputLabel htmlFor="movie-name">Movie Name</InputLabel>
                                <Input id="movie-name" />
                            </FormControl>
                            <br />
                            <FormControl className= {classes.formControl} >
                                <InputLabel id="demo-mutiple-checkbox-label">Genres</InputLabel>
                                <Select labelId="demo-mutiple-checkbox-label"
                                    id="demo-mutiple-checkbox"
                                    value={genres}
                                >
                                    {genrelist.map((genre) => (
                                        <MenuItem key={genre.id} value={genre.genre}>
                                            <Checkbox checked={genres.indexOf(genre.genre) > -1} />
                                            <ListItemText primary={genre.genre} />
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                            <br />
                            <FormControl className={classes.formControl}>
                                <InputLabel id="demo-artist-multiple-checkbox">Artists</InputLabel>
                                <Select labelId="demo-artist-mutiple-checkbox"
                                    id="demo-artist-mutiple-checkbox"
                                    value={artists}
                                >
                                    {
                                        artistlist.map((artist)=>(
                                            <MenuItem 
                                            key={artist.id}
                                            value={artist.first_name + " "+ artist.last_name}
                                            >
                                                <Checkbox 
                                                    checked={artists.indexOf(artist.first_name + " "+artist.last_name) > -1} />
                                                    <ListItemText primary={artist.first_name + " "+ artist.last_name} />
                                            </MenuItem>
                                        ))
                                    }
                                </Select>
                            </FormControl>
                            <br />
                            <FormControl className={classes.formControl}>
                                <TextField
                                id="release-date-start"
                                label="Release Date Start"
                                type="date"
                                defaultValue=""
                                InputLabelProps={{shrink:true}}
                                />
                            </FormControl>
                            <br />
                            <FormControl className={classes.formControl}>
                                <TextField
                                id="release-date-end"
                                label="Release Date End"
                                type="date"
                                defaultValue=""
                                InputLabelProps={{shrink:true}}
                                />
                            </FormControl>
                            <br />
                            <FormControl className={classes.formControl}>
                                <Button variant="contained" color="primary">
                                    APPLY
                                </Button>
                            </FormControl>
                        </CardContent>
                    </Card>
                </div>
            </div>


        </div>


    )
}