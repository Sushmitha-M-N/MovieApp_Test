import React, {useState,useEffect} from 'react';
import Home from './home/Home';
import { useDispatch } from 'react-redux';
import { Fragment } from 'react';
import {BrowserRouter as Router,Route} from 'react-router-dom';
import Details from '../screens/details/Details';
import BookShow from './bookshow/BookShow';
import Confirmation from './confirmation/Confirmation';
export default function Controller() {
    const [moviesList, setMoviesList] = useState([]);
    const dispatch = useDispatch();
    async function loadData() {
        console.log("inside load");
        const rawResponse = await fetch("http://localhost:8085/api/v1/movies");
        const data = await rawResponse.json();
        if(rawResponse.ok) {
            //
        }
       const upcomingMovies = data.movies.filter((upmovies)=>upmovies.status==="RELEASED")
       //const publishedMovies = data.movies.filter((upmovies)=>upmovies.status==="PUBLISHED")
        dispatch({"type":"SET_MOVIES",payload:data.movies})
        dispatch({"type":"SET_RELEASED_MOVIES",payload:upcomingMovies})
        setMoviesList(data);
    }
    async function getGenre() {
        const rawResponse = await fetch("http://localhost:8085/api/v1/genres");
        const data = await rawResponse.json();
        if(rawResponse.ok){
            console.log(data.genres);
            dispatch({"type":"SET_GENRES",payload:data.genres})
        }
        
    }
    async function getArtist() {
        const rawResponse = await fetch("http://localhost:8085/api/v1/artists");
        const data = await rawResponse.json();
        if(rawResponse.ok){
            console.log(data.artists);
            dispatch({"type":"SET_ARTIST",payload:data.artists})
        }       
    }
    async function movieDetail(movieId){
        const rawResponse = await fetch("http://localhost:8085/api/v1/movies/"+movieId);
        const data = await rawResponse.json();
        dispatch({"type":"SET_MOVIE_DETAILS",payload:data});
        dispatch({"type":"SET_MOVIE_ID",payload:movieId})
        if(rawResponse.ok){
            //
        }
        
    }

    useEffect(() => {
        loadData();
        getGenre();
        getArtist();
    }, []);
    
    return(
        <div>
            <Router>
                <Route exact path="/" render={(props)=><Home {...props} movieDetail={movieDetail} />} />
                <Route exact path ='/movie/:id' render={()=><Details/>}/>
                <Route exact path='/bookshow/:id' render={()=> <BookShow/>} />
                <Route exact path='/confirm/:id' render={()=> <Confirmation />} />
                 {/* <Home /> */}
            </Router>
            

        </div>          
    )
}