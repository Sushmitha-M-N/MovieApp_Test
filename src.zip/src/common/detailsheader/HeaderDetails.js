import React, { useState , useReducer} from 'react';
import './HeaderDetails.css';
import LoginDetails from '../detailslogin/LoginDetails';
import LogoutDetails from '../detailslogin/LogoutDetails';

import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router';
export default function HeaderDetails() {
    // const [login, setLogin] = useState({val:true});
    const loginOrlogoutDetails = useSelector(state=>state.statevalue);
    const dispatch = useDispatch();
    const history = useHistory();
    async function verifyUserHandlerDetails(email,password) {
        const param = window.btoa(`${email}:${password}`);
        try {
            const rawResponse = await fetch('http://localhost:8085/api/v1/auth/login', {         
                method: 'POST',
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json;charset=UTF-8",
                    authorization: `Basic ${param}`
                }
            });
    
            const result = await rawResponse.json();
            if(rawResponse.ok) {
                //Success
                // setLogin({val:false});
                //console.log(login.val);
                dispatch({"type":"SET_STATE",payload:false});
                <LogoutDetails />
            } else {
                // setLogin({val:true});
                dispatch({"type":"SET_STATE",payload:true});
                const error = new Error();
                error.message = 'Credentials is not correct';
                
            }
        } catch(e) {
            alert(`Error: ${e.message}`);
        }
    }
    const renderLoginPageDetails=()=>{
        // setLogin({val:true});
        dispatch({"type":"SET_STATE",payload:true});
        history.push("/");
    }
  async function  userRegisterHandlerDetails (firstname,lastname,emailid,passwordemail,contact) {
      const params = {
        email_address: emailid,
        first_name: firstname,
        last_name: lastname,
        mobile_number: contact,
        password: passwordemail
      }
        
        try {
            const rawResponse = await fetch('http://localhost:8085/api/v1/signup', {
            body: JSON.stringify(params),
            method: 'POST',
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json;charset=UTF-8"
            }
            });
    
            const result = await rawResponse.json();
            if(rawResponse.ok) {
                //Success
                console.log("Successful Registration");
                
            } else {
                const error = new Error();
                error.message = 'Credentials is not correct';
                throw error;
            }
        } catch(e) {
            alert(`Error: ${e.message}`);
        }
    }
    // const {val} = login;
    
    //  const isLoginSuccessful =()=>{   
    //      return val;
    //  }
    
   
    return (

        <div className="container">
            {/* {isLoginSuccessful() ?  <Logout /> : <Router><div><Route exact path="/login" render={(props) => <Login {...props} verifyUserHandler={verifyUserHandler} />} /> </div></Router>} */}
            {loginOrlogoutDetails ? <LoginDetails verifyUserHandlerDetails={verifyUserHandlerDetails} userRegisterHandlerDetails={userRegisterHandlerDetails} /> : <LogoutDetails  renderLoginPageDetails={renderLoginPageDetails}/>  }  

        </div>

    )
}