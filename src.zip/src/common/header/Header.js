import React, { useState , useReducer} from 'react';
import {BrowserRouter as Router,Route} from 'react-router-dom';
import './Header.css';
import Logout from '../login/Logout';
import Login from '../login/Login';
import { useDispatch, useSelector } from 'react-redux';
export default function Header() {
    // const [login, setLogin] = useState({val:true});
    const loginOrlogout = useSelector(state=>state.statevalue);
    const dispatch = useDispatch();
    async function verifyUserHandler(email,password) {
        const param = window.btoa(`${email}:${password}`);
        try {
            const rawResponse = await fetch('http://localhost:8085/api/v1/auth/login', {         
                method: 'POST',
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json;charset=UTF-8",
                    authorization: `Basic ${param}`
                }
            });
    
            const result = await rawResponse.json();
            if(rawResponse.ok) {
                //Success
                // setLogin({val:false});
                //console.log(login.val);
                dispatch({"type":"SET_STATE",payload:false});
                <Logout />
            } else {
                // setLogin({val:true});
                dispatch({"type":"SET_STATE",payload:true});
                const error = new Error();
                error.message = 'Credentials is not correct';
                
            }
        } catch(e) {
            alert(`Error: ${e.message}`);
        }
    }
    const renderLoginPage=()=>{
        // setLogin({val:true});
        dispatch({"type":"SET_STATE",payload:true});
        <Login />
    }
  async function  userRegisterHandler (firstname,lastname,emailid,passwordemail,contact) {
      const params = {
        email_address: emailid,
        first_name: firstname,
        last_name: lastname,
        mobile_number: contact,
        password: passwordemail
      }
        
        try {
            const rawResponse = await fetch('http://localhost:8085/api/v1/signup', {
            body: JSON.stringify(params),
            method: 'POST',
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json;charset=UTF-8"
            }
            });
    
            const result = await rawResponse.json();
            if(rawResponse.ok) {
                //Success
                console.log("Successful Registration");
                
            } else {
                const error = new Error();
                error.message = 'Credentials is not correct';
                throw error;
            }
        } catch(e) {
            alert(`Error: ${e.message}`);
        }
    }
    // const {val} = login;
    
    //  const isLoginSuccessful =()=>{   
    //      return val;
    //  }
    
   
    return (

        <div className="container">
            {/* {isLoginSuccessful() ?  <Logout /> : <Router><div><Route exact path="/login" render={(props) => <Login {...props} verifyUserHandler={verifyUserHandler} />} /> </div></Router>} */}
            {loginOrlogout ? <Login verifyUserHandler={verifyUserHandler} userRegisterHandler={userRegisterHandler} /> : <Logout  renderLoginPage={renderLoginPage}/>  }  

        </div>

    )
}