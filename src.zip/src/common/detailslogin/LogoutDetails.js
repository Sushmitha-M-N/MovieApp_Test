import React from 'react';
import logo from '../../assets/logo.svg';
import '../detailsheader/HeaderDetails.css';
import { Button } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import BookShow from '../../screens/bookshow/BookShow'
import { useHistory } from 'react-router';
import { useSelector } from "react-redux";
const useStyles = makeStyles((theme) => ({
  
    buttonStyle :{
        marginRight : 5,
    },

}));

export default function LogoutDetails(props) {
    //const statevalue = props.isLoginSuccessful();
    const movieId = useSelector(state=>state.movieID);
    const history = useHistory();
    const classes = useStyles();
    const onLogoutClicked= ()=>{
        props.renderLoginPageDetail();
        
    }
    const onBookShowClicked =(e) =>{
        history.push({pathname: "/bookshow/" +movieId});
    }
    return (
        <div className="header">
            <div className="logo">
                <img src={logo} className="App-logo" alt="logo" />
            </div>
            <div className="container-btn">
              <Button className={classes.buttonStyle} variant="contained" onClick={onBookShowClicked} color="primary">BookShow</Button>
              <Button variant="contained" color="default" onClick={onLogoutClicked}>Logout</Button>
              
            </div>
        </div>
    )

}